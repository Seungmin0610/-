package kr.ac.dankook.stud.shin.stoveleaguetracker.ui;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.time.LocalDate;
import java.util.ArrayList;

import kr.ac.dankook.stud.shin.stoveleaguetracker.R;

public class StoveFragment extends Fragment {

    private static final String TAG = "STOVE_FRAGMENT";
    private StoveAdapter adapter;
    private StoveViewModel viewModel;
    private ProgressBar progressBar;
    private Spinner spinnerDate, spinnerType;
    private Button btnDatePicker;

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        Log.d(TAG, "StoveFragment CREATED");

        View view = inflater.inflate(R.layout.fragment_stove, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.recyclerStove);
        progressBar = view.findViewById(R.id.progressLoading);
        spinnerDate = view.findViewById(R.id.spinnerDate);
        spinnerType = view.findViewById(R.id.spinnerType);
        btnDatePicker = view.findViewById(R.id.btnDatePicker);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new StoveAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);
        recyclerView.setVisibility(View.VISIBLE);
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemViewCacheSize(20);

        setupSpinners();
        setupDatePicker();

        viewModel = new ViewModelProvider(this).get(StoveViewModel.class);

        observeViewModel();

        viewModel.fetchMlbTransactions();  // 데이터 요청

        return view;
    }

    private void observeViewModel() {

        viewModel.getTrades().observe(getViewLifecycleOwner(), items -> {
            Log.d(TAG, "observe() 데이터 수 = " + items.size());
            adapter.updateItems(items);});

        viewModel.isLoading().observe(getViewLifecycleOwner(), isLoading ->
                progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE));
    }

    private void setupSpinners() {

        ArrayAdapter<String> dateAdapter =
                new ArrayAdapter<>(requireContext(),
                        android.R.layout.simple_spinner_item,
                        new String[]{"전체", "오늘", "최근 3일", "최근 5일", "최근 7일"});

        ArrayAdapter<String> typeAdapter =
                new ArrayAdapter<>(requireContext(),
                        android.R.layout.simple_spinner_item,
                        new String[]{"전체", "FA 계약", "트레이드", "양도 지명", "마이너리그 강등"});

        dateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerDate.setAdapter(dateAdapter);
        spinnerType.setAdapter(typeAdapter);

        AdapterView.OnItemSelectedListener listener =
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                        viewModel.applyFilter(
                                spinnerDate.getSelectedItem().toString(),
                                spinnerType.getSelectedItem().toString()
                        );
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {}
                };

        spinnerDate.setOnItemSelectedListener(listener);
        spinnerType.setOnItemSelectedListener(listener);
    }

    private void setupDatePicker() {

        btnDatePicker.setOnClickListener(v -> {

            LocalDate today = LocalDate.now();

            new DatePickerDialog(requireContext(),
                    (view, year, month, dayOfMonth) -> {

                        LocalDate selected =
                                LocalDate.of(year, month + 1, dayOfMonth);

                        // Spinner 초기화 후 DatePicker 필터 적용
                        spinnerDate.setSelection(0);
                        spinnerType.setSelection(0);

                        viewModel.filterByDate(selected);

                    },
                    today.getYear(),
                    today.getMonthValue() - 1,
                    today.getDayOfMonth()
            ).show();
        });
    }
}