package kr.ac.dankook.stud.shin.stoveleaguetracker.ui;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.gson.Gson;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Objects;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import kr.ac.dankook.stud.shin.stoveleaguetracker.model.TradeItem;
import kr.ac.dankook.stud.shin.stoveleaguetracker.model.TradeResponse;

public class StoveViewModel extends ViewModel {

    private static final String TAG = "STOVE_VM";

    // 원본 데이터
    private final ArrayList<TradeItem> allTrades = new ArrayList<>();

    // 화면에 보여줄 데이터
    private final MutableLiveData<ArrayList<TradeItem>> trades = new MutableLiveData<>();
    private final MutableLiveData<Boolean> loading = new MutableLiveData<>(true);

    public LiveData<ArrayList<TradeItem>> getTrades() {
        return trades;
    }

    public LiveData<Boolean> isLoading() {
        return loading;
    }

    public void fetchMlbTransactions() {

        Log.d(TAG, "fetchMlbTransactions() called");

        loading.postValue(true);

        OkHttpClient client = new OkHttpClient();

        String url =
                "https://statsapi.mlb.com/api/v1/transactions"
                        + "?sportId=1"
                        + "&startDate=2024-11-01"
                        + "&endDate=2026-01-15";

        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("User-Agent", "Android")
                .build();

        client.newCall(request).enqueue(new Callback() {

            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.e(TAG, "통신 실패", e);
                loading.postValue(false);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {

                if (!response.isSuccessful()) {
                    Log.e(TAG, "응답 실패");
                    loading.postValue(false);
                    return;
                }

                Log.d(TAG, "응답 성공");

                String json = Objects.requireNonNull(response.body()).string();

                Gson gson = new Gson();
                TradeResponse tradeResponse =
                        gson.fromJson(json, TradeResponse.class);

                allTrades.clear();
                allTrades.addAll(tradeResponse.getTransactions());

                allTrades.sort((a, b) -> b.getLocalDate().compareTo(a.getLocalDate()));

                trades.postValue(new ArrayList<>(allTrades));
                loading.postValue(false);
            }
        });
    }

    // 필터 적용 (날짜 + 계약 유형)
    public void applyFilter(String dateFilter, String typeFilter) {

        ArrayList<TradeItem> result = new ArrayList<>();
        LocalDate today = LocalDate.now();

        for (TradeItem item : allTrades) {

            // 계약 유형 필터
            if (!typeFilter.equals("전체") &&
                    !item.getKoreanType().equals(typeFilter)) {
                continue;
            }

            // 날짜 필터
            if (!dateFilter.equals("전체") &&
                    !matchDate(item.getLocalDate(), today, dateFilter)) {
                continue;
            }

            result.add(item);
        }

        trades.setValue(result);
    }

    public void filterByDate(LocalDate selectedDate) {

        ArrayList<TradeItem> result = new ArrayList<>();

        for (TradeItem item : allTrades) {
            if (item.getLocalDate().equals(selectedDate)) {
                result.add(item);
            }
        }

        trades.setValue(result);
    }

    private boolean matchDate(LocalDate itemDate, LocalDate today, String filter) {

        switch (filter) {
            case "오늘":
                return itemDate.equals(today);
            case "최근 3일":
                return !itemDate.isBefore(today.minusDays(3));
            case "최근 5일":
                return !itemDate.isBefore(today.minusDays(5));
            case "최근 7일":
                return !itemDate.isBefore(today.minusDays(7));
            default:
                return true;
        }
    }
}