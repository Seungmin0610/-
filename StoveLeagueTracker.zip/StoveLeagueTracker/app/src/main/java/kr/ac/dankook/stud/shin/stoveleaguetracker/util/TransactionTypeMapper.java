package kr.ac.dankook.stud.shin.stoveleaguetracker.util;

import java.util.HashMap;
import java.util.Map;

public class TransactionTypeMapper {
    private static final Map<String, String> TYPE_MAP = new HashMap<>();

    static {
        TYPE_MAP.put("DFA", "양도 지명");
        TYPE_MAP.put("TR", "트레이드");
        TYPE_MAP.put("SFA", "FA 계약");
        TYPE_MAP.put("OUT", "마이너리그 강등");

        // 이외에 자주 나오는 것들
        TYPE_MAP.put("MIN", "마이너리그 콜업");
        TYPE_MAP.put("DES", "지명 해제");
        TYPE_MAP.put("REL", "방출");
        TYPE_MAP.put("OPT", "옵션 이동");
        TYPE_MAP.put("CLAIM", "웨이버 클레임");
    }

    public static String toKorean(String typeCode) {
        if (typeCode == null) return "기타";

        String upper = typeCode.toUpperCase();
        return TYPE_MAP.getOrDefault(upper, upper);
    }
}
