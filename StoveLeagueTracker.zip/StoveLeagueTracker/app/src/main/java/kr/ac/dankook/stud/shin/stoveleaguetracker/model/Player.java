package kr.ac.dankook.stud.shin.stoveleaguetracker.model;

public class Player {
    private final String fullName;

    public Player(String fullName) {
        this.fullName = fullName;
    }

    public String getFullName() {
        return fullName;
    }
}
