package kr.ac.dankook.stud.shin.stoveleaguetracker.ui;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Objects;

import kr.ac.dankook.stud.shin.stoveleaguetracker.R;
import kr.ac.dankook.stud.shin.stoveleaguetracker.model.TradeItem;

public class StoveAdapter extends RecyclerView.Adapter<StoveAdapter.ViewHolder> {
    private static final String TAG = "STOVE_ADAPTER";
    private final ArrayList<TradeItem> items;
    public StoveAdapter(ArrayList<TradeItem> items) {
        this.items = items;
        Log.d(TAG, "Adapter 생성, 초기 size = " + items.size());
    }

    @SuppressLint("NotifyDataSetChanged")
    public void updateItems(ArrayList<TradeItem> newItems) {
        Log.d(TAG, "updateItems 호출됨 size=" + newItems.size());
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvPlayerName, tvTeam, tvType, tvContract, tvDate;
        MaterialCardView card;

        public ViewHolder(@NonNull View v) {
            super(v);
            card = v.findViewById(R.id.cardRoot);
            tvPlayerName = v.findViewById(R.id.tvPlayerName);
            tvTeam = v.findViewById(R.id.tvTeam);
            tvType = v.findViewById(R.id.tvType);
            tvContract = v.findViewById(R.id.tvContract);
            tvDate = v.findViewById(R.id.tvDate);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Log.d(TAG, "onCreateViewHolder");
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_stove_transaction, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        TradeItem item = items.get(position);
        Log.d(TAG, "onBindViewHolder position = " + position);
        if (item == null) return;

        if (h.tvPlayerName != null) {
            String name = item.getPlayerName();
            h.tvPlayerName.setText(name != null ? name : "");
        }

        if (h.tvTeam != null) {
            h.tvTeam.setText(item.getFromTeamName() + " -> " + item.getToTeamName());
        }

        String type = null;
        if (h.tvType != null) {
            type = item.getType();
            if (type != null && !type.isEmpty()) {
                h.tvType.setVisibility(View.VISIBLE);
                h.tvType.setText(item.getKoreanType());
            } else {
                h.tvType.setVisibility(View.GONE);
            }
        }

        int color;
        int icon = 0;

        if (Objects.requireNonNull(type).contains("SFA")) {
            color = R.color.type_fa;
            icon = R.drawable.ic_fa;
        } else if (type.contains("TR")) {
            color = R.color.type_trade;
            icon = R.drawable.ic_trade;
        } else if (type.contains("DFA")) {
            color = R.color.type_dfa;
            icon = R.drawable.ic_dfa;
        } else if (type.contains("OUT")) {
            color = R.color.type_degradation;
            icon = R.drawable.ic_degradation;
        } else {
            color = R.color.type_default;
        }

        h.tvType.setTextColor(
                h.itemView.getContext().getColor(color)
        );

        if (icon != 0) {
            h.tvType.setCompoundDrawablesWithIntrinsicBounds(icon, 0, 0, 0);
        } else {
            h.tvType.setCompoundDrawables(null, null, null, null);
        }

        if (h.tvDate != null) {
            String date = item.getDate();
            h.tvDate.setText(date != null ? date : "");
        }

        if (LocalDate.parse(item.getDate()).equals(LocalDate.now())) {
            h.tvDate.setTextColor(Color.parseColor("#FF5722"));
        } else {
            h.tvDate.setTextColor(Color.parseColor("#960437"));
        }

        if (h.tvContract != null) {
            String contract = item.getContractInfo();
            if (contract != null && !contract.isEmpty()) {
                h.tvContract.setVisibility(View.VISIBLE);
                h.tvContract.setText(contract);
            } else {
                h.tvContract.setVisibility(View.GONE);
            }
        }

        h.itemView.setOnClickListener(v -> {
            PlayerDetailFragment fragment =
                    PlayerDetailFragment.newInstance(item);

            ((AppCompatActivity) v.getContext())
                    .getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack("player_detail")
                    .commit();
        });
    }

    @Override
    public int getItemCount() {
        Log.d(TAG, "getItemCount = " + items.size());
        return items.size();
    }
}