package kr.ac.dankook.stud.shin.stoveleaguetracker;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "stove_transactions")
public class StoveTransaction {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String playerName;
    public String fromTeam;
    public String toTeam;
    public String type;      // FA, 트레이드, 방출
    public String contract;  // "4년 80억"
    public String date;      // yyyy-MM-dd

    public StoveTransaction(String playerName, String fromTeam,
                            String toTeam, String type,
                            String contract, String date) {
        this.playerName = playerName;
        this.fromTeam = fromTeam;
        this.toTeam = toTeam;
        this.type = type;
        this.contract = contract;
        this.date = date;
    }
}