package kr.ac.dankook.stud.shin.stoveleaguetracker.data;

import java.util.HashMap;
import java.util.Map;

public class ContractInfoStore {
    private static final Map<String, String> CONTRACT_MAP = new HashMap<>();

    static {
        // 유명 선수들만 따로 수동 등록
        // API에 계약 기간, 금액 같은 조건 필드들이 법적, 상업적 이유로 존재하지 않음
        CONTRACT_MAP.put("Juan Soto", "15년 7억 6,500만 달러");
        CONTRACT_MAP.put("Shohei Ohtani", "10년 7억 달러");
        CONTRACT_MAP.put("Yoshinobu Yamamoto", "12년 3억 2500만 달러");
        CONTRACT_MAP.put("Aaron Judge", "9년 3억 6000만 달러");
        CONTRACT_MAP.put("Mike Trout", "12년 4억 2650만 달러");
    }

    public static String getContract(String playerName) {
        if (playerName == null) return null;
        return CONTRACT_MAP.get(playerName);
    }
}
