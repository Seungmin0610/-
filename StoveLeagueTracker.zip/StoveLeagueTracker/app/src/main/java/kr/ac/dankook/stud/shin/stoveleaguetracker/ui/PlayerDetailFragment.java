package kr.ac.dankook.stud.shin.stoveleaguetracker.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.Objects;

import kr.ac.dankook.stud.shin.stoveleaguetracker.R;
import kr.ac.dankook.stud.shin.stoveleaguetracker.model.TradeItem;

public class PlayerDetailFragment extends Fragment {
    private static final String ARG_ITEM = "trade_item";

    public static PlayerDetailFragment newInstance(TradeItem item) {
        PlayerDetailFragment fragment = new PlayerDetailFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_ITEM, item);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_player_detail, container, false);

        TradeItem item = (TradeItem) Objects.requireNonNull(getArguments()).getSerializable(ARG_ITEM);

        ((TextView) view.findViewById(R.id.tvPlayerName))
                .setText(Objects.requireNonNull(item).getPlayerName());

        ((TextView) view.findViewById(R.id.tvTeam))
                .setText(item.getToTeamName());

        ((TextView) view.findViewById(R.id.tvType))
                .setText(item.getKoreanType());

        ((TextView) view.findViewById(R.id.tvDate))
                .setText(item.getDate());

        ((TextView) view.findViewById(R.id.tvContract))
                .setText(item.getContractInfo());

        return view;
    }
}