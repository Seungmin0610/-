package kr.ac.dankook.stud.shin.stoveleaguetracker.model;

import com.google.gson.annotations.SerializedName;

import java.time.LocalDate;
import java.io.Serializable;

import kr.ac.dankook.stud.shin.stoveleaguetracker.util.TransactionTypeMapper;
import kr.ac.dankook.stud.shin.stoveleaguetracker.data.ContractInfoStore;
public class TradeItem implements Serializable{

    private final String date;
    @SerializedName("transactionTypeDescription")
    private String transactionTypeDescription;

    @SerializedName("typeCode")
    private String typeCode;

    private final Player player;

    private final Player person;

    private final Team fromTeam;
    private final Team toTeam;

    public TradeItem(String date, Player player, Player person, Team fromTeam, Team toTeam) {
        this.date = date;
        this.player = player;
        this.person = person;
        this.fromTeam = fromTeam;
        this.toTeam = toTeam;
    }

    public String getDate() {
        return date;
    }

    public LocalDate getLocalDate() {
        return LocalDate.parse(date); // date = "2025-12-20"
    }

    public String getType() {
        if (transactionTypeDescription != null && !transactionTypeDescription.isEmpty())
            return transactionTypeDescription;

        if (typeCode != null && !typeCode.isEmpty())
            return typeCode;

        return "유형 정보 없음";
    }

    public String getKoreanType() {
        return TransactionTypeMapper.toKorean(typeCode);
    }

    public String getPlayerName() {
        if (player != null && player.getFullName() != null) return player.getFullName();
        if (person != null && person.getFullName() != null) return person.getFullName();

        if (transactionTypeDescription != null) {
            if (transactionTypeDescription.contains("Draft"))
                return "드래프트 픽";

            if (transactionTypeDescription.contains("PTBNL"))
                return "추후 지명 선수";

            if (transactionTypeDescription.contains("Cash"))
                return "현금 트레이드";
        }

        return "선수 정보 없음";
    }

    public String getFromTeamName() {
        return fromTeam != null && fromTeam.getName() != null
                ? fromTeam.getName() : "이전 팀 없음";
    }

    public String getToTeamName() {
        return toTeam != null  && toTeam.getName() != null
                ? toTeam.getName() : "이후 팀 없음";
    }

    public String getContractInfo() {
        String name = getPlayerName();
        String contract = ContractInfoStore.getContract(name);

        if (contract != null) {
            return contract;
        }
        return "";
    }
}