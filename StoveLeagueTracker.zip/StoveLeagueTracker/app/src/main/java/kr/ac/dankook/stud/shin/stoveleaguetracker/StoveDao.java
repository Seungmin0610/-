package kr.ac.dankook.stud.shin.stoveleaguetracker;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;
@Dao
public interface StoveDao {

    @Query("SELECT * FROM stove_transactions ORDER BY date DESC")
    List<StoveTransaction> getAll();

    @Insert
    void insert(StoveTransaction transaction);

    @Query("DELETE FROM stove_transactions")
    void clear();
}