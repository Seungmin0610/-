package kr.ac.dankook.stud.shin.stoveleaguetracker.model;

import java.util.List;

public class TradeResponse {

    private final List<TradeItem> transactions;

    public TradeResponse(List<TradeItem> transactions) {
        this.transactions = transactions;
    }

    public List<TradeItem> getTransactions() {
        return transactions;
    }
}